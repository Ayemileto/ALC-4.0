package com.futamall.https.oloriireproject;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Menu;
import android.view.MenuItem;


public class AboutAlc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_alc);

        WebView aboutALC = findViewById(R.id.webview_page);

        ConnectivityManager connectivity_service = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivity_service.getActiveNetworkInfo();


        if(networkInfo == null)
        {
            String errorMessage = "<br><br><br>Cannot Connect To The Internet, Check Your Network and Try Again";
            aboutALC.loadData(errorMessage, "text/html", "UTF-8");
        }
        else if(networkInfo .isConnected())
        {
            aboutALC.setWebViewClient(new WebViewClient());
            WebSettings newSettings = aboutALC.getSettings();
            newSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
            newSettings.setJavaScriptEnabled(true);
            newSettings.setDisplayZoomControls(true);

            aboutALC.loadUrl("http://andela.com/alc");
        }
        else
        {
            String errorMessage = "<br><br><br>Cannot Connect To The Internet, Check Your Network and Try Again";
            aboutALC.loadData(errorMessage, "text/html", "UTF-8");
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.back_btn) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
